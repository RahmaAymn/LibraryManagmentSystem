import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class Library {
    private Map<String, User> users;  
    private Map<String, Book> books;  
    private static final int MAX_EXTENSIONS = 3;
    private static final long EXTENSION_PERIOD_DAYS = 7;
    public Library() {
        this.users = new HashMap<>();
        this.books = new HashMap<>();
    }

    public void loadUsersFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] userData = line.split(",");
                String username = userData[0];
                String password = userData[1];
                String role = userData[2];
                boolean isBanned = Boolean.parseBoolean(userData[3]);
                int age = Integer.parseInt(userData[4]);
                String gender = userData[5];
                users.put(username, new User(username, password, role, isBanned, age, gender));
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void loadBooksFromFile(String filePath) {
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            Book currentBook = null;

            while ((line = reader.readLine()) != null) {
                line = line.trim();

                if (line.contains(",")) {
                    String[] bookData = line.split(",");
                    if (bookData.length == 3) {
                        String title = bookData[0].trim();
                        String genre = bookData[1].trim();
                        int availableCopies = Integer.parseInt(bookData[2].trim());
                        currentBook = new Book(title, genre, availableCopies);
                        books.put(title, currentBook);  
                    } else {
                        int rating = Integer.parseInt(bookData[0].trim());
                        String review = bookData[1].trim();
                        if (currentBook != null) {
                            Rating ratingObj = new Rating(rating, review);
                            currentBook.addRating(ratingObj);
                        }
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

     public static List<BorrowRecord> loadBorrowRecordsFromFile(String filePath) {
        List<BorrowRecord> borrowRecords = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 3) {
                    String bookTitle = parts[0];
                    LocalDate borrowDate = LocalDate.parse(parts[1]);
                    LocalDate dueDate = LocalDate.parse(parts[2]);
                    BorrowRecord record = new BorrowRecord(bookTitle, borrowDate, dueDate);
                    borrowRecords.add(record);
                }
            }
        } catch (IOException e) {
            System.out.println("Error loading borrow records: " + e.getMessage());
        }
        return borrowRecords;
    }
    
    
    private void saveBorrowRecordToFile(User user, String bookTitle, int durationWeeks) {
        try (FileWriter writer = new FileWriter("BorrowRecords.txt", true)) { 
            writer.write("User: " + user.getUsername() + ", Book: " + bookTitle + ", Duration: " + durationWeeks + " weeks\n");
            System.out.println("Borrow record saved successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while saving the borrow record: " + e.getMessage()) ; } 
        }

    
    public void saveUsersToFile(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (User user : users.values()) {
                writer.write(user.getUsername() + "," + user.getPassword() + "," + user.getRole() + ","
                        + user.isBanned() + "," + user.getAge() + "," + user.getGender() + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void saveBooksToFile(String filePath) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (Book book : books.values()) {
                writer.write(book.getTitle() + "," + book.getGenre() + "," + book.getAvailableCopies() + "\n");

                for (Rating rating : book.getRatings()) {
                    writer.write(rating.getRating() + "," + rating.getReview() + "\n");
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    
    public User loginUser(String username, String password) {
        User user = users.get(username);
        if (user != null && user.getPassword().equals(password) && !user.isBanned()) {
            return user;
        }
        return null;
    }

    public void registerUser(String username, String password, String role, int age, String gender) {
        if (!users.containsKey(username)) {
            users.put(username, new User(username, password, role, false, age, gender));
        } else {
            System.out.println("User already exists.");
        }
    }

    public void addBook(String title, String genre, int availableCopies) {
        if (!books.containsKey(title)) {
            books.put(title, new Book(title, genre, availableCopies));
            saveBooksToFile("books.txt"); 
        } else {
            System.out.println("Book already exists.");
        }
    }

   public String borrowBook(User user, String bookTitle, int durationWeeks, Scanner scanner) {
    Book book = findBookByTitle(bookTitle); 
    
    if (book != null) {
        for (BorrowRecord record : user.getBorrowedBooks()) {
            if (record.getBookTitle().equals(bookTitle)) {
                return "You have already borrowed the book '" + bookTitle + "' and cannot borrow it again at this time.";
            }
        }
        if (book.getAvailableCopies() > 0) {
            book.setAvailableCopies(book.getAvailableCopies() - 1);  
            user.borrowBook(bookTitle, durationWeeks);
            saveBorrowRecordToFile(user, bookTitle, durationWeeks);

            return "You have successfully borrowed the book '" + bookTitle + "' for " + durationWeeks + " week(s).";
        } else {
           
            System.out.println("Sorry, no copies available for '" + bookTitle + "'.");
            System.out.print("Would you like to reserve it? (yes/no): ");
            String response = scanner.nextLine().trim().toLowerCase();
    
            if (response.equals("yes")) {
                String reserveMessage = reserveBook(user, bookTitle); 
                return reserveMessage; 
            } else {
                return "You chose not to reserve the book.";
            }
        }
    } else {
        return "The book '" + bookTitle + "' does not exist in the library.";
    }
}



    private Book findBookByTitle(String bookTitle) {
        return books.get(bookTitle); 
    }
    
    public String reserveBook(User user, String bookTitle) {
        Book book = findBookByTitle(bookTitle); 
        
        if (book != null) {
            if (book.isAvailable()) {
                return "The book '" + bookTitle + "' is available for borrowing. You cannot reserve it.";
            } else {
                if (user.getReservedBooks().contains(book)) {
                    return "The book '" + bookTitle + "' has already been reserved for you.";
                } else {
                    user.addReservedBooks(book); 
                    book.reserveBook(user);  
                    return "The book '" + bookTitle + "' has been reserved for you.";
                }
            }
        } else {
            return "The book '" + bookTitle + "' does not exist in the library.";
        }
    }
    
    

    @SuppressWarnings("resource")
    public String returnBook(User user, String bookTitle) {
        for (BorrowRecord record : user.getBorrowedBooks()) {
            if (record.getBookTitle().equals(bookTitle)) {
                user.removeBorrowRecord(record);  
    
                Book book = books.get(bookTitle);  
                System.out.println("Would you like to rate and review the book? (y/n)");
                Scanner scanner = new Scanner(System.in);
                String response = scanner.nextLine().toLowerCase();
                
                if (response.equals("y")) {
                    System.out.println("Please enter your rating (1-5):");
                    int rating = scanner.nextInt();
                    scanner.nextLine();  
                    System.out.println("Please enter your review (optional):");
                    String userReview = scanner.nextLine();
        
                    rateAndReviewBook(book, rating, userReview);
                }
                if (book != null) {
                    book.setAvailableCopies(book.getAvailableCopies() + 1);  
                    if (book.getReservedUsers() != null && !book.getReservedUsers().isEmpty()) {
                        book.notifyUsers();  
                    }
    
                    return "Book returned successfully.";
                } else {
                   
                    System.out.println("Error: Book with title '" + bookTitle + "' not found in library.");
                    return "Book not found in the library.";
                }
            }
        }
    
        return "You haven't borrowed this book.";
    }
    
     public void checkOverdueBooks(User user) {
        boolean hasBorrowedBooks = false; 
        double totalFineIncrease= 0.0 ;


        for (BorrowRecord record : user.getBorrowedBooks()) {
            hasBorrowedBooks = true;
            long remainingDays = record.getRemainingDays();
            String bookTitle = record.getBookTitle();

            if (remainingDays > 0) {
                System.out.println("Book: '" + bookTitle + "' is due in " + remainingDays + " days.");
            } else {
                System.out.println("Book: '" + bookTitle + "' is overdue. Please return it.");
                totalFineIncrease += calculateOverdueFineForBook(record);

            }
        }

        if (!hasBorrowedBooks) {
            System.out.println("You have not borrowed any books.");
        }

       if (totalFineIncrease > 0) {
            System.out.println("Your overdue fine has increased by: $" + totalFineIncrease);
        } else {
            System.out.println("No overdue fines.");
        }
    }

    public void rateAndReviewBook(Book book, int rating, String review) {
        if (rating < 1 || rating > 5) {
            System.out.println("Rating must be between 1 and 5.");
            return;
        }

        Rating userRating = new Rating(rating, review);

        book.addRating(userRating); 
        System.out.println("Thank you for your rating and review!");
    }





    public void banUser(User admin, String username) {
        if (admin.getRole().equals("admin")) {
            User user = users.get(username);
            if (user != null) {
                user.setBanned(true);
                saveUsersToFile("users.txt");
                System.out.println("User " + username + " has been banned.");
            } else {
                System.out.println("User not found.");
            }
        }
    }

    public void unbanUser(User admin, String username) {
        if (admin.getRole().equals("admin")) {
            User user = users.get(username);
            if (user != null) {
                user.setBanned(false);
                saveUsersToFile("users.txt");
                System.out.println("User " + username + " has been unbanned.");
            } else {
                System.out.println("User not found.");
            }
        }
    }

    public void displayBooksWithRatings() {
        for (Book book : books.values()) {
            System.out.println(book.getTitle() + " - Average Rating: " + book.getAverageRating());
        }
    }


    

    public void viewAllUsers() {
        for (User user : users.values()) {
            System.out.println(user.getUsername() + " | Role: " + user.getRole() + " | Banned: " + user.isBanned());
        }
    }
    public void viewAllBooks() {
        for (Book book : books.values()) {
            System.out.println("Title: " + book.getTitle());
            System.out.println("Genre: " + book.getGenre());
            System.out.println("Available Copies: " + book.getAvailableCopies());
    
            double averageRating = book.getAverageRating();
            if (averageRating > 0) {
                System.out.println("Average Rating: " + averageRating + "/5");
            } else {
                System.out.println("No ratings yet.");
            }
    
            System.out.println("Reviews:");
            if (book.getRatings().isEmpty()) {
                System.out.println("No reviews yet.");
            } else {
                for (Rating rating : book.getRatings()) {
                    System.out.println("Rating: " + rating.getRating() + "/5");
                    System.out.println("Review: " + rating.getReview());
                    System.out.println("---");
                }
            }
            System.out.println("________________");
        }
    }
    

    public void removeBook(String title) {
    if (books.containsKey(title)) {
        books.remove(title);
        System.out.println("Book " + title + " has been removed.");
        saveBooksToFile("books.txt"); 

    } else {
        System.out.println("Book not found.");
    }
}

public void deleteUser(String username) {
    if (users.containsKey(username)) {
        users.remove(username);
        saveUsersToFile("users.txt");
        System.out.println("User " + username + " has been deleted.");
    } else {
        System.out.println("User not found.");
    }
}

public void editUserProfile(String username, String password, String role, int age, String gender) {
    if (users.containsKey(username)) {
        User user = users.get(username);
        user.setPassword(password);
        user.setRole(role);
        user.setAge(age);
        user.setGender(gender);
        saveUsersToFile("users.txt");
        System.out.println("User " + username + "'s profile has been updated.");
    } else {
        System.out.println("User not found.");
    }
}

 public void editOwnProfile(User currentUser, String password, int age, String gender) {
        if (users.containsKey(currentUser.getUsername())) {
            User user = users.get(currentUser.getUsername());
            user.setPassword(password);
            user.setAge(age);
            user.setGender(gender);
            saveUsersToFile("users.txt");
            System.out.println("Your profile has been updated.");
        } else {
            System.out.println("User not found.");
        }
    }
    


public void checkUserBookStatus(User currentUser) {
    boolean hasOverdueBooks = false; 

    for (BorrowRecord record : currentUser.getBorrowedBooks()) {
        long remainingDays = record.getRemainingDays();  

        if (remainingDays < 0) {
            System.out.println(currentUser.getUsername() + " you have an overdue book: " + record.getBookTitle() + 
                               " (Overdue by " + Math.abs(remainingDays) + " days).");
            hasOverdueBooks = true; 
        }
    }

    if (!hasOverdueBooks) {
        System.out.println(currentUser.getUsername() + " you have no overdue books.");
    }

   if (!currentUser.getReservedBooks().isEmpty()) {
    for (Book reservedBook : currentUser.getReservedBooks()) {
        System.out.println("Reserved book(s): " + reservedBook.getTitle());
    }
} else {
    System.out.println(currentUser.getUsername() + " you have no reserved books.");
}


    if (!currentUser.getBorrowedBooks().isEmpty()) {
        System.out.println(currentUser.getUsername() + " you have borrowed the following books:");
        for (BorrowRecord record : currentUser.getBorrowedBooks()) {
            long remainingDays = record.getRemainingDays(); 

            if (remainingDays < 0) {
                System.out.println("Overdue book(s): " + record.getBookTitle() + " (Overdue by " + Math.abs(remainingDays) + " days).");
            } 
           
            else {
                System.out.println("Borrowed book(s): " + record.getBookTitle() + " with " + remainingDays + " days remaining.");
            }
        }
    } else {
        System.out.println(currentUser.getUsername() + " you have not borrowed any books.");
    }
}

public void searchBook(Scanner scanner) {
    System.out.println("Do you want to search by genre or name? (genre/name)");
    String searchType = scanner.nextLine().trim().toLowerCase();

    List<Book> searchResults = new ArrayList<>();
    
    if (searchType.equals("genre")) {
        System.out.println("Enter the genre you want to search for:");
        String genre = scanner.nextLine().trim().toLowerCase();
        for (Book book : books.values()) {
            if (book.getGenre().toLowerCase().contains(genre)) {
                searchResults.add(book);
            }
        }
    } else if (searchType.equals("name")) {
        System.out.println("Enter the book name or keyword you want to search for:");
        String keyword = scanner.nextLine().trim().toLowerCase();
        for (Book book : books.values()) {
            if (book.getTitle().toLowerCase().contains(keyword)) {
                searchResults.add(book);
            }
        }
    } else {
        System.out.println("Invalid choice. Please select either 'genre' or 'name'.");
        return;
    }

    if (searchResults.isEmpty()) {
        System.out.println("No books found matching your search criteria.");
        return;
    }

    System.out.println("Do you want to sort the results? (yes/no)");
    String sortChoice = scanner.nextLine().trim().toLowerCase();

    if (sortChoice.equals("yes")) {
        System.out.println("Sort by rating or name? (rating/name)");
        String sortBy = scanner.nextLine().trim().toLowerCase();

        if (sortBy.equals("rating")) {
            searchResults.sort((b1, b2) -> Double.compare(b2.getAverageRating(), b1.getAverageRating()));
        } else if (sortBy.equals("name")) {
            searchResults.sort(Comparator.comparing(Book::getTitle));
        } else {
            System.out.println("Invalid sorting option. Showing unsorted results.");
        }
    }

    System.out.println("Search Results:");
    for (Book book : searchResults) {
        System.out.println("Title: " + book.getTitle());
        System.out.println("Genre: " + book.getGenre());
        System.out.println("Available Copies: " + book.getAvailableCopies());
        System.out.println("Average Rating: " + (book.getAverageRating() > 0 ? book.getAverageRating() + "/5" : "No ratings yet."));
        System.out.println("________________");
    }
}
public double calculateBorrowingFee(BorrowRecord record) {
    final double BORROWING_FEE_PER_DAY = 1.0; 

    long daysBorrowed = ChronoUnit.DAYS.between(record.getBorrowDate(), record.getDueDate());

    double borrowingFee = daysBorrowed * BORROWING_FEE_PER_DAY;
    return borrowingFee;
}

public double calculateOverdueFineForBook(BorrowRecord record) {
    final double OVERDUE_FINE_PER_DAY = 2.0;

    long remainingDays = record.getRemainingDays();

    if (remainingDays <= 0) {
        long overdueDays = Math.abs(remainingDays); 
        double overdueFine = overdueDays * OVERDUE_FINE_PER_DAY;  
        return overdueFine; 
    }
    return 0.0;  
}

public double calculateTotalFine(User user) {
    double totalFine = 0.0;  

    for (BorrowRecord record : user.getBorrowedBooks()) {
        double borrowingFee = calculateBorrowingFee(record);

        double overdueFine = calculateOverdueFineForBook(record);

        totalFine += borrowingFee + overdueFine;

        System.out.println("Book: '" + record.getBookTitle() + "' - Borrowing Fee: $" + borrowingFee);
        if (overdueFine > 0) {
            System.out.println("Overdue Fine for this book: $" + overdueFine);
        }
    }

    return totalFine;  
}

public void displayFineDetails(User user) {
    double totalFine = calculateTotalFine(user);
    double costPerDay = 1.0;  

    System.out.println("Fine Details for User: " + user.getUsername());
    System.out.println("--------------------------------------------------");

    
    System.out.println("Total Fine: $" + totalFine);
    System.out.println("--------------------------------------------------");

    for (BorrowRecord record : user.getBorrowedBooks()) {
        double borrowingFee = calculateBorrowingFee(record);
        double overdueFine = calculateOverdueFineForBook(record);
        System.out.println("Book: " + record.getBookTitle());
        System.out.println("   Borrowing Fee: $" + borrowingFee);
        if (overdueFine > 0) {
            System.out.println("   Overdue Fine: $" + overdueFine);
        }
    }

    System.out.println("--------------------------------------------------");
    System.out.println("Payment Method: You can pay your fines via Cash or Online Payment.");
    System.out.println("Cost to Borrow a Book per Day: $" + costPerDay);
    System.out.println("--------------------------------------------------");
}

public boolean canRequestExtension(User user) {
    if (user.getNumberOfExtensions() >= MAX_EXTENSIONS) {
        System.out.println("You have already reached the maximum number of extensions.");
        return false;
    }

    if (hasOverdueBooks(user)) {
        System.out.println("You cannot request an extension because you have overdue books.");
        return false;
    }

    if (hasUnpaidFines(user)) {
        System.out.println("You cannot request an extension because you have unpaid fines.");
        return false;
    }

    return true;  
}

private boolean hasOverdueBooks(User user) {
    for (BorrowRecord record : user.getBorrowedBooks()) {
        if (record.isOverdue()) {
            return true;
        }
    }
    return false;
}

private boolean hasUnpaidFines(User user) {
    double totalFine = calculateTotalFine(user);
    return totalFine > 0;  
}

public String requestExtension(User user, String bookTitle) {
    if (!canRequestExtension(user)) {
        return "Extension request denied.";
    }

    for (BorrowRecord record : user.getBorrowedBooks()) {
        if (record.getBookTitle().equals(bookTitle)) {
            LocalDate newDueDate = record.getDueDate().plusDays(EXTENSION_PERIOD_DAYS);
            record.setDueDate(newDueDate);
            user.incrementExtensions();

            return "Extension approved. The new due date is: " + newDueDate;
        }
    }

    return "Book not found in your borrowed books.";
}
}



